# Test ve hata ayıklama

Çalıştırma: `python -m unittest -v`. Sonuç: **12 test başarılı**, 6 Kasım 2026. Her satır ilgili test fonksiyonuna karşılık gelir; gruplanan uç girdiler alt testlerle kontrol edilir.

| No | Girdi / işlem | Beklenen | Gerçek |
|---|---|---|---|
| 01 | `125,50` | Decimal 125.50 | 125.50; geçti |
| 02 | `0`, `-10`, `abc`, `NaN`, `Infinity`, `1.234`, `1000000.01`, boş | Her biri reddedilir | Hepsi ValueError; geçti |
| 03 | `1000000` | Üst sınır kabul edilir | 1000000.00; geçti |
| 04 | `2032-02-29`; geçersiz `2030-02-29`, `2030-13-01`, `2030-5-1`, boş | Artık yıl kabul, diğerleri ret | Beklendiği gibi; geçti |
| 05 | ` GELIR `; geçersiz tür, boş/kısa/uzun açıklama, formül ve satır sonu | Tür normalleşir, hatalar reddedilir | Beklendiği gibi; geçti |
| 06 | Gelir 0.10 + 0.20, gider 0.30 | Bakiye tam 0.00 | Decimal 0.00; geçti |
| 07 | Boş liste; yalnız 50 TL gider | Kayıt yok mesajı; bütçe açığı | İki mesaj da üretildi; geçti |
| 08 | `Müzik, efekt paketi`, 125.50 kaydet ve oku | Türkçe/virgül/tutar korunur | Okunan liste aynı; geçti |
| 09 | Yanlış başlıklı CSV ile açılış | Uyarı, dosya korunur | Baytlar değişmedi; geçti |
| 10 | Menüde 9; 1000 gelir; önce -3 sonra 250,50 gider; rapor; tekrar aç | Uyarılar, bakiye 749.50, rapor ve kalıcılık | Hepsi doğrulandı; geçti |
| 11 | Kayıt sırasında yazma izni hatası benzetimi | Bellekte sahte kayıt oluşmaz | Liste boş kaldı; geçti |
| 12 | Tutar için `abc` sonra `12,50`; menüde EOF | Tekrar sorar; düzgün sonlanır | 12.50 ve iptal mesajı; geçti |

## Yakalanan gerçek eksiklik

İlk YZ test kodu `TemporaryDirectory()` ile sistemin geçici dizininde yazma izni olduğunu varsaydı. İlk koşuda 4 test dosya izin hatası verdi. İz yığınına bakılarak test ortamı sorunu ayrıştırıldı. Geçici dizin test dosyasının bulunduğu yazılabilir klasörde oluşturulunca 12 test geçti. Uygulama güvenliğini kapatmak yerine testin dizin seçimi düzeltildi.

## Ek teknik karar

Para tutarlarında `float` yerine `Decimal` kullanılır. `0.1 + 0.2 - 0.3` ikili kayan nokta temsili nedeniyle tam sıfır değildir. `Decimal('0.10') + Decimal('0.20') - Decimal('0.30')` tam sıfırdır. Test 06 bu nedenle yalnızca ekrandaki yuvarlanmış metni değil hesap sonucunu da kontrol eder.
