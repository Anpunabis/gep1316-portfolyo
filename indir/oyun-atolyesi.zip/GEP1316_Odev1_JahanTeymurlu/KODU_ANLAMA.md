# Sözlü doğrulama için kodu anlama notları

Bu notları okuyup programı kendiniz çalıştırın. Amaç cevap ezberlemek yerine kodun davranışını açıklayabilmektir.

1. **Neden liste ve sözlük birlikte var?** Her işlem `tarih`, `tur`, `aciklama`, `tutar` alanlarını taşıyan bir sözlüktür. Bu sözlüklerin tamamı `kayitlar` listesinde saklanır.
2. **Hatalı tutarda ne olur?** `tutar_dogrula` bir `ValueError` üretir. `girdi_al` bu hatayı yakalar, mesajı gösterir ve `while True` sayesinde aynı soruyu yeniden sorar.
3. **Menü neden kapanmıyor?** `main` içindeki döngü seçimlerden sonra başa döner. `0` seçilince `break` döngüyü bitirir.
4. **İki karar yapısı nerede?** Menüdeki `if/elif/else` seçenekleri ayırır. `toplam_hesapla` içindeki `if/else` geliri ve gideri ayırır. `rapor_metni` bakiyenin işaretine göre mesaj seçer.
5. **Bakiye nasıl hesaplanır?** Kayıtlar sırayla gezilir; gelirler ve giderler ayrı toplanır, `gelir - gider` döndürülür. Negatif sonuç bütçe açığıdır.
6. **Neden Decimal?** Para kuruş hassasiyeti gerektirir. Metinden oluşturulan `Decimal`, 0.10 ve 0.20 gibi değerleri ondalık olarak tam temsil eder.
7. **CSV ne işe yarar?** Kayıtları program kapandıktan sonra korur ve tablo yazılımlarının okuyabildiği metin çıktısı üretir. `csv.DictWriter` alan adlarına göre satır yazar.
8. **Günlük rapor nasıl seçilir?** Liste üreteci, tarihi istenen güne eşit kayıtları yeni bir listeye alır. Hesap sadece bu liste üzerinden yapılır.
9. **Kayıt önce neden dosyaya yazılır?** Yazma başarısız olduğunda bellekte kaydedilmiş gibi görünmemesi gerekir. `kayitlar.append` yalnız başarılı yazmadan sonra çalışır.
10. **Bozuk dosyada neden program kapanır?** Yanlış verinin üstüne boş liste yazıp mevcut kayıtları kaybetmemek için. Dosya korunur, hata açıklanır.

## Kendin dene

- 1000 gelir ve 250,50 gider ekle. Sonuç neden 749,50?
- Tutar yerine `abc`, sonra `12,50` gir. Programın neden çökmediğini kodda göster.
- `2030-02-29` gir. `2032-02-29` neden farklı sonuç verir?
- Programı kapatıp aç; dosyadan okunan kayıtları göster.
- Başka bir tarihin günlük raporunu iste; genel toplamın neden değişmediğini açıkla.
- Testleri çalıştır ve `test_06_kesin_para_hesabi` içindeki üç değeri kendin hesapla.
