# Gerçek sohbetten prompt günlüğü

Araç: OpenAI Codex. Tarih: 6 Kasım 2026.

Bu kayıtlar öğrencinin bu sohbette gerçekten gönderdiği mesajlara dayanır. Alıntıların yazımı okunabilirlik için düzeltilmiştir; yanıtlar özetlenmiştir. Değerlendirmeler öğrencinin isteğiyle YZ tarafından hazırlanmıştır. Öğrencinin testleri kendi bilgisayarında yaptığı veya asistanın bulduğu hatayı bizzat bulduğu iddia edilmez. Öğrenci kabul/red/düzenleme önerilerini okuyup kendi görüşüne uymayanları değiştirmelidir.

## 1. Uygulamanın hazırlanması
**Gerçek istem:** “Bir ödevin iki ayrı parçası var; önce birincisini yap.”

**Ek kullanıcı bilgisi:** “Jahan Teymurlu, Dijital Oyun Tasarımı.”

**YZ yanıtının özeti:** PDF şartlarına göre gelir-gider kaydı, bakiye ve günlük CSV raporu içeren komut satırı uygulaması; kod, testler ve belgeler hazırlandı.

**Değerlendirme önerisi: Düzenleme.** İlk düşünülen genel kasa defteri, bölüm bilgisi verildikten sonra oyun geliştirme bütçesine uyarlandı. Bu değişiklik senaryonun meslek alanıyla ilişkisini güçlendirdi.

## 2. Ödev ve kullanım açıklaması
**Gerçek istem:** “Bu dosyayı nasıl açacağım? Hoca tam olarak ne istiyor? Bana biraz anlatsana.”

**YZ yanıtının özeti:** ZIP'in çıkarılması, PDF'in açılması ve `python main.py` komutu anlatıldı. Kod, test tablosu, rapor, GitHub, prompt günlüğü ve beyan gereksinimleri açıklandı.

**Değerlendirme önerisi: Kabul.** Dosyaların görevleri ve çalıştırma gereksinimi anlaşılır hale geldi. Belgeyi açmakla Python programını çalıştırmanın farklı işlemler olduğu açıklığa kavuştu.

## 3. Çalışma iddiasının doğrulanması
**Gerçek istem:** “Her şey tam çalışıyor mu? Bende yok da, hoca açabilecek değil mi? Bir kontrol et.”

**YZ yanıtının özeti:** Asistan ZIP'i yeni bir klasöre çıkararak 12 testi yeniden çalıştırdı; ayrı program süreçlerinde kayıt ekleme, yanlış giriş, yeniden açılış ve CSV raporunu kontrol etti. Python 3.10+ gerektiğini belirtti.

**Değerlendirme önerisi: Kabul.** Yalnızca 'çalışır' denmesi yerine gerçek kontrol yapıldı. 1000 TL gelirden 250,50 TL gider çıkarıldığında 749,50 TL bakiye oluştuğu dosya içeriğinden de doğrulandı. Bu kontrolleri asistan yaptı.

## 4. Teslim biçiminin kontrolü
**Gerçek istem:** “Hocaya sadece ZIP dosyasını yollasam olur mu?”

**YZ yanıtının özeti:** ZIP'in yanında GitHub deposu bağlantısının gerektiği, beyan ve kişisel belgelerin incelenmesi gerektiği açıklandı.

**Değerlendirme önerisi: Red / düzeltme.** Yalnız ZIP'in tüm teslim şartlarını karşılayacağı varsayımı reddedildi. PDF'te GitHub deposu da istendiğinden teslimin buna göre düzenlenmesi gerekiyor. GitHub yüklemesi yapılmış gibi gösterilmedi.

## 5. Yansıtma ve beyanın düzenlenmesi
**Gerçek istem:** “Kişisel yansıtma, kendi prompt değerlendirmeleri ve beyan imzası bunlar ne, nasıl yapacağım? Sen yapsana.”

**YZ yanıtının özeti:** Yansıtma, öğrencinin ödevi hazırlatması, açıklama istemesi ve kontrolleri asistana yaptırması üzerinden yazıldı. Önceki alt görev notlarının yerine bu beş gerçek sohbet istemi konuldu. Beyana isim ve tarih eklendi; imza alanı öğrenciye bırakıldı.

**Değerlendirme önerisi: Düzenleme.** Öğrencinin söylemediği öğrenme veya test deneyimlerini uydurmak yerine gerçek süreç anlatıldı. Öğrenci belgeyi okuyup uygunluğunu kontrol ettikten sonra kendisi imzalamalıdır.

## YZ'nin yakalanan gerçek eksikliği

İlk test kodu, sistemin geçici dizininde dosya yazma ve temizleme izni olduğunu varsaydı. İlk çalıştırmada 12 testin 4'ü `PermissionError` verdi. Asistan hata izini inceleyip `TemporaryDirectory()` yerine `TemporaryDirectory(dir=Path(__file__).resolve().parent)` kullandı. Sonraki çalıştırmada 12/12 test geçti. Böylece YZ'nin ortam varsayımının eksik olduğu gerçek çalıştırmada görüldü. Teşhis ve düzeltme asistan tarafından yapıldı; öğrencinin bizzat bulduğu şeklinde sunulmadı.
