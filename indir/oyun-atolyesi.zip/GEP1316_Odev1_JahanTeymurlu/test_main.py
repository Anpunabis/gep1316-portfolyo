"""Gerçek dosya işlemleri ve etkileşimli menü için otomatik kontroller."""
import contextlib
import io
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

import main as app


class ButceTestleri(unittest.TestCase):
    def test_01_virgullu_tutar(self):
        self.assertEqual(app.tutar_dogrula("125,50"), Decimal("125.50"))

    def test_02_hatali_tutarlar(self):
        for deger in ("0", "-10", "abc", "NaN", "Infinity", "1.234", "1000000.01", ""):
            with self.subTest(deger=deger), self.assertRaises(ValueError):
                app.tutar_dogrula(deger)

    def test_03_sinir_tutar(self):
        self.assertEqual(app.tutar_dogrula("1000000"), Decimal("1000000.00"))

    def test_04_tarih(self):
        self.assertEqual(app.tarih_dogrula("2032-02-29"), "2032-02-29")
        for deger in ("2030-02-29", "2030-13-01", "2030-5-1", ""):
            with self.subTest(deger=deger), self.assertRaises(ValueError):
                app.tarih_dogrula(deger)

    def test_05_tur_aciklama(self):
        self.assertEqual(app.tur_dogrula(" GELIR "), "gelir")
        for deger in ("", "x", "=SUM(A1:A2)", "a" * 61, "a\nb"):
            with self.subTest(deger=deger), self.assertRaises(ValueError):
                app.aciklama_dogrula(deger)
        with self.assertRaises(ValueError):
            app.tur_dogrula("borç")

    def test_06_kesin_para_hesabi(self):
        kayitlar = [{"tur": "gelir", "tutar": Decimal("0.10")},
                    {"tur": "gelir", "tutar": Decimal("0.20")},
                    {"tur": "gider", "tutar": Decimal("0.30")}]
        self.assertEqual(app.toplam_hesapla(kayitlar),
                         (Decimal("0.30"), Decimal("0.30"), Decimal("0.00")))

    def test_07_bos_ve_negatif_butce(self):
        self.assertIn("Henüz kayıt yok", app.rapor_metni([], "TEST"))
        kayit = {"tarih": "2030-05-10", "tur": "gider", "aciklama": "Ses paketi", "tutar": Decimal("50")}
        self.assertIn("bütçe açığı", app.rapor_metni([kayit], "TEST"))

    def test_08_csv_gidip_gelme(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as klasor:
            dosya = Path(klasor) / "veriler.csv"
            self.assertEqual(app.kayitlari_oku(dosya), [])
            kayitlar = [{"tarih": "2030-05-10", "tur": "gider", "aciklama": "Müzik, efekt paketi", "tutar": Decimal("125.50")}]
            app.csv_kaydet(dosya, app.ALANLAR, kayitlar)
            self.assertEqual(app.kayitlari_oku(dosya), kayitlar)

    def test_09_bozuk_dosya_korunur(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as klasor:
            dosya = Path(klasor) / "veriler.csv"
            dosya.write_text("yanlis,sutun\n1,2\n", encoding="utf-8")
            once = dosya.read_bytes()
            with contextlib.redirect_stdout(io.StringIO()) as cikti:
                app.main(dosya)
            self.assertIn("Mevcut dosya değiştirilmedi", cikti.getvalue())
            self.assertEqual(dosya.read_bytes(), once)

    def test_10_tam_menu_ve_yeniden_acma(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as klasor:
            dosya = Path(klasor) / "veriler.csv"
            girdiler = ["9", "1", "2030-05-10", "gelir", "Oyun satış geliri", "1000",
                        "1", "2030-05-10", "gider", "Ses paketi", "-3", "250,50",
                        "2", "3", "2030-05-10", "0"]
            with patch("builtins.input", side_effect=girdiler), contextlib.redirect_stdout(io.StringIO()) as cikti:
                app.main(dosya)
            self.assertIn("749,50 TL", cikti.getvalue())
            self.assertIn("Uyarı:", cikti.getvalue())
            self.assertEqual(len(app.kayitlari_oku(dosya)), 2)
            rapor = Path(klasor) / "rapor_2030-05-10.csv"
            self.assertIn("1000.00,250.50,749.50", rapor.read_text(encoding="utf-8-sig"))
            with patch("builtins.input", side_effect=["2", "0"]), contextlib.redirect_stdout(io.StringIO()) as cikti2:
                app.main(dosya)
            self.assertIn("749,50 TL", cikti2.getvalue())

    def test_11_yazma_hatasi_bellege_eklenmez(self):
        kayitlar = []
        with patch("builtins.input", side_effect=["2030-05-10", "gelir", "Satış", "100"]), patch.object(app, "csv_kaydet", side_effect=PermissionError("Test: izin yok")):
            with self.assertRaises(PermissionError):
                app.kayit_ekle(kayitlar, Path("test.csv"))
        self.assertEqual(kayitlar, [])

    def test_12_eof_ve_yeniden_girdi(self):
        with patch("builtins.input", side_effect=["abc", "12,50"]), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(app.girdi_al("Tutar: ", app.tutar_dogrula), Decimal("12.50"))
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as klasor:
            with patch("builtins.input", side_effect=EOFError), contextlib.redirect_stdout(io.StringIO()) as cikti:
                app.main(Path(klasor) / "veriler.csv")
            self.assertIn("İşlem iptal edildi", cikti.getvalue())


if __name__ == "__main__":
    unittest.main(verbosity=2)

