# Oyun Atölyesi - Oyun Geliştirme Bütçe Takibi

**Jahan Teymurlu | Dijital Oyun Tasarımı | GEP1316 | Ödev 1**

2030 yılında küçük bir bağımsız oyun ekibinin gelir ve giderlerini izlemek için hazırlanmış Python komut satırı uygulaması. Oyun satışı ve etkinlik gelirleri ile ses, çizim, yazılım ve ekipman harcamalarını tek yerde toplar. Bütçenin durumunu gösterir ve tarih bazında CSV raporu üretir. Örneklerdeki veriler kurgusaldır.

## Çalıştırma

Python 3.10 veya üzeri yeterlidir. Harici paket gerekmez. ZIP'i önce bir klasöre çıkarın; o klasörde terminal açın:

```sh
python main.py
```

Windows'ta `python` bulunamazsa `py main.py`, macOS/Linux'ta `python3 main.py` deneyin. Python kurulu değilse Python 3 kurup terminali yeniden açın. Uygulama klasörüne yazma izni gerekir.

## Kullanım

1. `1` ile kayıt ekleyin. Örnek tarih: `2030-05-10`, tür: `gelir`, açıklama: `Oyun satış geliri`, tutar: `1000`.
2. İkinci kayıt için aynı tarih, `gider`, `Ses paketi`, `250,50` girin.
3. `2` ile toplam gelirin 1000,00 TL, giderin 250,50 TL, bakiyenin 749,50 TL olduğunu görün.
4. `3` ile `2030-05-10` tarihli raporu kaydedin.
5. `0` ile çıkın. Sonraki açılışta kayıtlar geri yüklenir.

Tutar pozitif ve en fazla 1.000.000 TL olabilir; en fazla iki ondalık basamak kullanılır. `125,50` ve `125.50` kabul edilir. Binlik ayırıcı kullanılmaz. Geçersiz girişte soru yeniden sorulur. Tarihler takvime göre doğrulanır. Açıklama 2-60 karakterdir. CSV formülü olarak yorumlanabilecek başlangıç karakterleri reddedilir.

## Çalıştırma çıktıları

Aşağıdaki görseller gerçek program çalıştırmasından kaydedilmiş terminal metninin görselleştirilmesidir; masaüstü ekran yakalaması değildir. Ham kayıtlar aynı klasördedir. Teslimde birebir terminal ekran görüntüsü isteniyorsa uygulamayı açıp kendi ekran görüntünüzü ayrıca ekleyin.

![Kayıtlar ve bütçe özeti](docs/butce_ciktisi.png)

![Hatalı tutar ve geçerli giriş](docs/hata_ciktisi.png)

## Dosyalar

| Dosya | Görevi |
|---|---|
| `main.py` | Uygulama |
| `test_main.py` | 12 otomatik test |
| `PROMPTLAR.md` | Gerçek sohbetten beş istem, yanıt ve değerlendirme |
| `RAPOR.md` / `RAPOR.pdf` | Düzenlenebilir kaynak ve 3 sayfalık rapor |
| `TESTLER.md` | Girdi, beklenen sonuç, gerçek sonuç tablosu |
| `YZ_BEYAN.md` | İncelenip imzalanacak beyan |
| `docs/` | Gerçek çalıştırma metinleri, test sonucu ve görseller |

İlk kayıtta `veriler.csv`, rapor istendiğinde `rapor_YYYY-AA-GG.csv` uygulamanın bulunduğu klasörde oluşur. CSV UTF-8 BOM ile yazılır; tutarlar dosyada noktalı ondalık biçimindedir. Excel'de gerekirse **Veri > Metinden/CSV'den** ile virgül ayırıcı seçin. Bozuk veri dosyası sessizce sıfırlanmaz; program uyarıyla kapanır. Dosyayı yedekleyip hatalı satırı düzeltin. Aynı klasörde aynı anda tek uygulama açın. Uygulama tek para birimi (TL) kullanır; muhasebe veya vergi yazılımı değildir.

## Test

```sh
python -m unittest -v
```

12 test, 6 Kasım 2026 tarihinde geliştirme ortamında başarıyla çalıştırıldı. Dosya testleri uygulama klasöründe geçici dizin oluşturur ve temizler; mevcut kullanıcı verilerini değiştirmez.

## Ders kavramları

- Dört doğrulanan girdi: tarih, tür, açıklama, tutar.
- Kararlar: menü, gelir/gider ayrımı, bakiye değerlendirmesi.
- Döngüler: menü, tekrar giriş, kayıtları okuma ve toplama.
- Fonksiyonlar: `girdi_al`, `toplam_hesapla`, `kayit_ekle`, `gunluk_rapor` ve doğrulayıcılar.
- Veri yapıları: kayıt listesi ve her kayıt için sözlük.
- Dosya çıktısı: kayıtlar ve günlük rapor CSV olarak saklanır.
- Para hesabı: `Decimal` ile kuruş doğruluğu korunur.

## GitHub ve teslim

Bu paket henüz GitHub'a yüklenmedi ve Teams'e gönderilmedi. GitHub'da bir depo açıp bu klasördeki dosyaları **Add file > Upload files** ile yükleyebilirsiniz. `veriler.csv` gibi kişisel kullanım verilerini yüklemeyin. Depo bağlantısını teslim açıklamasına ekleyin. Öğretmenin erişebileceği görünürlüğü seçin.

Teslimden önce kodu ve belgeleri okuyun. Yansıtma ve beş prompt değerlendirmesi gerçek sohbet sürecine göre YZ desteğiyle hazırlanmıştır; kendi görüşünüzle uyuştuğunu kontrol edin. Beyanda ad ve tarih doludur; imzayı öğrenci atmalıdır. Çalıştırma kontrolleri asistan tarafından yapılmıştır. Öğrenci kendi bilgisayarında denemiş gibi gösterilmemiştir. GitHub yüklemesi henüz yapılmamıştır.

Paket adı: `GEP1316_Odev1_JahanTeymurlu.zip`. Birinci ödevin teslim tarihi: **15 Kasım 2026, 23:59 (MS Teams > Ödevler)**.
