# Öğrenci Yapay Zekâ Kullanım Beyan Formu

| Alan | Yanıt |
|---|---|
| Kullanılan YZ aracı/araçları | OpenAI Codex |
| Kullanma amacı | Problem ve algoritma tasarımı; Python kodu, testler, hata ayıklama ve belge taslaklarının hazırlanması |
| Öğrencinin adı-soyadı | Jahan Teymurlu |
| Bölüm | Dijital Oyun Tasarımı |
| Tarih ve İmza | 06.11.2026 — Öğrenci imzası: __________________ |

**Kontrol ve sorumluluk (inceleme sonrası öğrenci tarafından onaylanacak):** Yapay zekâ tarafından üretilen içeriği gözden geçirdiğimi, gerekli düzeltmeleri yaptığımı ve teslim ettiğim çalışmanın doğruluğundan ve akademik dürüstlüğünden sorumlu olduğumu beyan ederim.

Bu metin henüz öğrenci adına imzalanmış bir beyan değildir. Öğrenci kodu ve testleri çalıştırmalı, gerçek sohbet sürecine göre yazılan yansıtmayı ve prompt değerlendirmelerini okuyup doğruluğunu kontrol etmelidir. Metinler YZ desteğiyle hazırlanmıştır.

## APA 7 kaynakça

OpenAI. (2026). *Codex* [Yapay zekâ destekli kodlama aracı]. https://openai.com/codex/

Model sürümü kullanıcı arayüzünden doğrulanmadığı için sürüm adı eklenmemiştir. Ürün yılı bu kullanımın gerçekleştiği yıldır.
