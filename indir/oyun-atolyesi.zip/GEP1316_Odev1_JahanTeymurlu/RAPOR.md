# OYUN ATÖLYESİ - Süreç Raporu

Hazırlayan: Jahan Teymurlu | Dijital Oyun Tasarımı | GEP1316 | 06.11.2026

> Kodun, testlerin ve belgelerin hazırlanmasında OpenAI Codex kullanıldı. Teknik kontroller asistan tarafından yapıldı.

## 1. Problem ve kullanıcı

Bu uygulama için 2030 yılında küçük bir bağımsız oyun ekibinde çalıştığımı düşündüm. Üç kişilik ekibimiz bir oyun prototipi geliştiriyor. Oyundan ve katıldığımız etkinliklerden gelir elde ederken ses, görsel ve geliştirme araçları için para harcıyoruz. Bu işlemler farklı mesajlarda veya kâğıtlarda tutulduğunda ne kadar paramız kaldığını takip etmek zorlaşıyor. Unutulan bir ödeme ya da yanlış toplanan bir tutar, yeni bir harcama yaparken sorun çıkarabiliyor.

Programı kullanacak kişi, ekibin bütçesini takip eden oyun tasarımcısı veya proje sorumlusu. Her işlem için tarih, gelir ya da gider bilgisi, kısa bir açıklama ve tutar giriliyor. Program bu bilgileri kontrol edip kaydediyor. Yanlış bir giriş yapılırsa kullanıcıyı uyarıyor ve aynı bilgiyi yeniden istiyor. Böylece örneğin tutar yerine yazı girilmesi programın kapanmasına yol açmıyor.

Kullanıcı ister bütün kayıtları ister yalnızca belirli bir günün işlemlerini görebiliyor. Gelir ve gider ayrı ayrı toplanıyor; aradaki fark kalan bütçeyi veriyor. Giderler gelirden fazlaysa ekranda uyarı çıkıyor. Günlük özet CSV dosyasına kaydedilebildiği için daha sonra bir tablo programında da açılabiliyor. Kayıtların dosyada tutulması sayesinde program her açıldığında aynı işlemleri tekrar girmek gerekmiyor.

Bu sürümde yalnızca TL kullanılıyor ve aynı anda tek kişinin çalışması bekleniyor. Fatura, vergi veya banka hesabı gibi ayrıntılar yok. Ad, telefon veya müşteri bilgisi istenmiyor. Amaç, küçük bir oyun ekibinin günlük gelir ve gider takibini kolaylaştırmak. Programın menü, fonksiyon, liste ve sözlük yapılarıyla kurulması da derste işlenen konuların tek bir örnekte kullanılmasını sağlıyor.

## 2. Tasarım / sözde kod

```text
BAŞLA
CSV varsa oku ve her satırı doğrula; bozuksa dosyayı koruyarak çık.
MENÜYÜ TEKRARLA:
  1 ise: tarih, tür, açıklama, tutar al; yanlışsa yeniden sor.
         Yeni listeyi CSV'ye yaz; başarılıysa belleğe ekle.
  2 ise: kayıtları göster; gelir/gider topla; bakiyeyi yorumla.
  3 ise: tarih al; o günün kayıtlarını seç; özeti göster ve CSV yaz.
  0 ise: döngüden çık.
  Diğer seçimlerde: uyar ve menüye dön.
Dosya yazma hatasında uyar; kesme/EOF durumunda düzgün sonlan.
BİTİR
```

## 3. YZ ile çalışma günlüğü

YZ: OpenAI Codex. Aşağıdaki beş istem, bu sohbetin gerçek öğrenci mesajlarının anlamı korunarak kısaltılmış halidir. Kabul/red/düzenleme gerekçeleri YZ desteğiyle hazırlanmış değerlendirme önerileridir; öğrenci kontrol etmelidir. Tam kayıt PROMPTLAR.md dosyasındadır.

### 1 / Uygulama
İstem: İki parçalı ödevin önce birincisini yap

Yanıt/karar: Kod, test ve belgeler hazırlandı. Düzenleme önerisi: genel kasa konusu, verilen bölüm bilgisiyle oyun ekibi bütçesine uyarlandı.

### 2 / Açıklama
İstem: Bu dosyayı nasıl açacağım; hoca ne istiyor?

Yanıt/karar: ZIP çıkarma, Python çalıştırma ve teslim şartları açıklandı. Kabul önerisi: yalnız dosyayı almak yerine kullanım ve şartları anlamayı destekliyor.

### 3 / Kontrol
İstem: Her şey çalışıyor mu; hoca açabilecek mi? Kontrol et

Yanıt/karar: Temiz ZIP kopyasında 12 test ve ayrı süreçlerde kayıt/rapor doğrulandı. Kabul önerisi: çalışma iddiası testle desteklendi; Python gereksinimi açıklandı.

### 4 / Teslim
İstem: Hocaya sadece ZIP dosyasını yollasam olur mu?

Yanıt/karar: GitHub deposu ve kişisel belgelerin de gerektiği açıklandı. Red gerekçesi: yalnız ZIP'in tüm teslim şartlarını karşıladığı varsayımı eksikti.

### 5 / Belgeleri düzenleme
İstem: Yansıtma, prompt değerlendirmesi ve beyanı sen tamamla

Yanıt/karar: Yansıtma gerçek sohbet sürecine göre yazıldı; günlük gerçek mesajlarla yenilendi. Düzenleme: ad/tarih dolduruldu, imza öğrenciye bırakıldı.

## 4. Test ve hata ayıklama

Girdi / işlem | Beklenen | Gerçek
125,50 | 125.50 kabul | 125.50 / geçti
-10, 0, abc, NaN | Uyarı / reddet | Reddedildi / geçti
2030-02-29 | Geçersiz tarih | Reddedildi / geçti
1000 gelir; 250,50 gider | Bakiye 749,50 | 749,50 / geçti
0.10 + 0.20 - 0.30 | Tam 0.00 | Decimal 0.00 / geçti
Kaydet ve yeniden aç | 2 kayıt korunur | 2 kayıt / geçti
Bozuk CSV başlığı | Dosyayı koru | Değişmedi / geçti

Gerçek hata ayıklama: İlk test kodu sistemin geçici dizininde yazma izni varsaydı. 12 testin 4'ü PermissionError verdi. İz yığını dosya erişimini işaret etti. TemporaryDirectory konumu yazılabilir proje klasörüne alındı; yeniden koşuda 12/12 geçti. Bu eksiklik uygulama hesabında değil YZ'nin test ortamı varsayımındaydı. Para işlemlerinde ayrıca float yerine Decimal kullanıldı.

## 5. Yansıtma - YZ desteğiyle hazırlanmış metin (231 kelime)

Bu ödev için bölümümle bağlantılı, günlük hayatta işe yarayabilecek küçük bir uygulama hazırlatmak istedim. Oyun Atölyesi fikri bu yüzden uygun geldi. Bir oyunun tasarımını yaparken kullanılan seslerin, görsellerin ve araçların maliyeti de önemli. Gelirleri ve harcamaları aynı yerde görmek, ekibin elindeki bütçeyi takip etmesini kolaylaştırabilir. Kodlamanın yalnızca oyunun içinde değil, yapım sürecinde de kullanılabileceğini bu örnek üzerinden değerlendirdim.

Kodun ve belgelerin hazırlanmasında Codex'ten destek aldım. Dosyaları aldıktan sonra nasıl açacağımı ve hocanın tam olarak ne istediğini sordum. Bilgisayarımda Python olmadığı için programın çalışmasını da asistana kontrol ettirdim. ZIP'ten çıkarılan kopyada on iki testin geçtiği, kayıtların program yeniden açıldığında korunduğu ve günlük raporun doğru hesaplandığı bildirildi. Bu sonuçların dosya olarak pakette bulunması, yapılan kontrolü inceleyebilmemi sağlıyor.

Programda tarih, işlem türü, açıklama ve tutar alınıyor. Menü bir döngüyle tekrar ediyor; karar yapıları hangi işlemin yapılacağını belirliyor. Fonksiyonlar da kayıt ekleme, hesaplama ve rapor oluşturma işlerini ayırıyor. Kayıtlar liste ve sözlüklerle tutuluyor, CSV dosyasına yazılıyor. Para hesabında Decimal kullanılıyor. İlk testlerde çıkan geçici klasör izin hatasını asistan bulup düzeltti.

YZ olmadan böyle bir programın tamamını tek başıma yazabildiğimi henüz gösteremedim. Önce menüyü ve basit hesaplamaları anlayarak başlayıp dosya işlemlerini daha sonra çalışmak istiyorum. Kodun ne yaptığını kendi cümlelerimle açıklayabilmek benim için sonraki adım. Oyun tasarımı alanında benzer araçları bütçe, içerik listesi ve görev takibi için kullanmak isterim. Bu çalışmayı teslim etmeden önce metinleri okuyup kendi deneyimime uyduğunu kontrol etmem ve anlamadığım bölümleri öğrenmem gerekiyor.

## 6. Öğrenci YZ kullanım beyanı

Araç: OpenAI Codex. Amaç: tasarım, kod, test, hata ayıklama ve belge taslakları.

Yapay zekâ tarafından üretilen içeriği gözden geçirdiğimi, gerekli düzeltmeleri yaptığımı ve teslim ettiğim çalışmanın doğruluğundan ve akademik dürüstlüğünden sorumlu olduğumu beyan ederim.

Ad-soyad: Jahan Teymurlu

Tarih: 06.11.2026

APA 7: OpenAI. (2026). *Codex* [Yapay zekâ destekli kodlama aracı]. https://openai.com/codex/
